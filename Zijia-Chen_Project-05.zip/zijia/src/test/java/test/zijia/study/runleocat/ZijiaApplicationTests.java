package test.zijia.study.runleocat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import test.zijia.study.runleocat.mallGood.dao.entity.MallGood;
import test.zijia.study.runleocat.mallGood.dao.entity.repo.MallGoodRepository;
import test.zijia.study.runleocat.mallOrder.dao.entity.MallOrder;
import test.zijia.study.runleocat.mallOrder.dao.entity.MallOrderGood;
import test.zijia.study.runleocat.mallOrder.dao.entity.repo.MallOrderGoodRepository;
import test.zijia.study.runleocat.mallOrder.dao.repo.MallOrderRepository;
import test.zijia.study.runleocat.mallUser.dao.entity.MallUser;
import test.zijia.study.runleocat.mallUser.dao.repo.MallUserRepository;

import javax.annotation.Resource;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@SpringBootTest
class ZijiaApplicationTests {

    @Test
    void contextLoads() {
    }
    @Resource
    MallUserRepository mallUserRepository;
    @Test
    void testSelect(){
//       mallUserRepository.findById(1L);
       mallUserRepository.findByMallUserName("leo01");
       mallUserRepository.findByUPBySQL("leo01");
//       mallUserRepository.save();
    }
    @Test
    void testSave(){
        MallUser mallUser = new MallUser();
        mallUser.setMallUserName("leo01");
        mallUser.setMallUserPassword("123456");
        mallUser.setMallUserAddress("CN");
        mallUserRepository.save(mallUser);

        System.out.println(mallUser.getMallUserId());
        System.out.println(mallUser.getMallUserAddress());

        mallUser.setMallUserAddress("US");
        mallUserRepository.save(mallUser);

        System.out.println(mallUser.getMallUserId());
        System.out.println(mallUser.getMallUserAddress());
    }
//    @Transactional
    @Test
    void testUpdate(){
//        MallUser mallUser = mallUserRepository.findByMallUserName("leo01");
        mallUserRepository.updateUserByName("CN","leo01");
//        mallUserRepository.delete(mallUser);

    }
    @Test
    void testDelete(){

        MallUser mallUser = mallUserRepository.findByMallUserName("leo01");
        mallUserRepository.delete(mallUser);

        mallUserRepository.deleteByMallUserName("leo01");

        mallUserRepository.deleteUserByUserName("leo01");
    }

    @Test
    void insertOrder(){

        MallUser mallUser = mallUserRepository.findByMallUserName("leo01");
        MallOrder mallOrder = new MallOrder();
        mallOrder.setMallOrderName("O01");
        mallOrder.setMallUser(mallUser);

        Set<MallOrder> mallOrders = new HashSet<>();
        mallOrders.add(mallOrder);

        mallUser.setMallOrders(mallOrders);

        mallUserRepository.save(mallUser);
    }

    @Test
    void testInit(){
        System.out.println("init table");
    }

    @Resource
    MallOrderGoodRepository mallOrderGoodRepository;

    @Resource
    MallGoodRepository mallGoodRepository;

    @Resource
    MallOrderRepository mallOrderRepository;
    @Test
    // not suggest
    void insertOrderAndGood1() {

        MallUser mallUser = mallUserRepository.findByMallUserName("leo01");
        MallOrder mallOrder = new MallOrder();
        mallOrder.setMallOrderName("O01");
        mallOrder.setMallUser(mallUser);

        Set<MallOrder> mallOrders = new HashSet<>();
        mallOrders.add(mallOrder);

        mallUser.setMallOrders(mallOrders);
        mallUser = mallUserRepository.save(mallUser);

        mallOrders = mallUser.getMallOrders();

        Iterator moit = mallOrders.iterator();
        while (moit.hasNext()){
            MallOrder mallOrderTemp = (MallOrder) moit.next();
            MallOrderGood mallOrderGood = new MallOrderGood();
            mallOrderGood.setMallOrder(mallOrderTemp);

            MallGood mallGood = mallGoodRepository.findById(1L).get();
            mallOrderGood.setMallGood(mallGood);

            mallOrderGoodRepository.save(mallOrderGood);
        }


    }
    @Test
    void insertOrderAndGood2(){

        MallUser mallUser = mallUserRepository.findByMallUserName("leo01");
        MallOrder mallOrder = new MallOrder();
        mallOrder.setMallOrderName("O02");
        mallOrder.setMallUser(mallUser);

        Set<MallOrderGood> mallOrderGoods = new HashSet<>();

        MallOrderGood mallOrderGood = new MallOrderGood();
        mallOrderGood.setMallOrderName(mallOrder.getMallOrderName());
        mallOrderGood.setMallOrder(mallOrder);

        MallGood mallGood = mallGoodRepository.findById(1L).get();
        mallOrderGood.setMallGood(mallGood);

        mallOrderGoods.add(mallOrderGood);


        mallOrder.setMallOrderGoods(mallOrderGoods);
        mallGood.setMallOrderGoods(mallOrderGoods);

        Set<MallOrder> mallOrders = new HashSet<>();
        mallOrders.add(mallOrder);

        mallUser.setMallOrders(mallOrders);

        mallUserRepository.save(mallUser);
    }
}
