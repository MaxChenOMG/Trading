package test.zijia.study.runleocat.mallUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import test.zijia.study.runleocat.mallUser.service.MallUserService;

import javax.annotation.Resource;

@SpringBootTest
public class MallUserTest {
    @Resource
    MallUserService mallUserService;

    @Test
    @Transactional
    void testMallGoodAndOrder(){
        mallUserService.getUserOrderAndGoods("leo01");
    }

}
