package test.zijia.study.runleocat.mallUser.dao.entity;

import lombok.Getter;
import lombok.Setter;
import test.zijia.study.runleocat.mallOrder.dao.entity.MallOrder;

import javax.persistence.*;
import java.util.Collection;
import java.util.Set;

@Setter
@Getter
@Entity
@Table(name = "mall_user")
public class MallUser {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "mall_user_id", nullable = false)
    private Long mallUserId;

    private String mallUserName;
    private String mallUserPassword;
    private String mallUserAddress;
    private String mallUserRealName;


    @OneToMany(cascade = CascadeType.MERGE, mappedBy = "mallUser")
    private Set<MallOrder> mallOrders;

}
