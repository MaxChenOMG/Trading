package test.zijia.study.runleocat.mallGood.dao.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import test.zijia.study.runleocat.mallGood.dao.entity.MallGood;

public interface MallGoodRepository extends JpaRepository<MallGood, Long> {
}