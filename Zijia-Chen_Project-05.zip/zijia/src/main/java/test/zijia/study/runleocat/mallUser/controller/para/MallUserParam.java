package test.zijia.study.runleocat.mallUser.controller.para;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MallUserParam {
    @NotBlank(message = "mall user name should not be null")
    private String mallUserName;
    @NotBlank(message = "mall user password should not be null")
    private String mallUserPassword;
    private String mallUserAge;

    private Long mallGoodId;
}
