package test.zijia.study.runleocat.demo.service;

import java.util.*;

/**
 * 
 */
public interface DemoService {

    public void getAllEmpOfDeptServ() ;
}