package test.zijia.study.runleocat.mallOrder.dao.entity.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import test.zijia.study.runleocat.mallOrder.dao.entity.MallOrderGood;

public interface MallOrderGoodRepository extends JpaRepository<MallOrderGood, Long> {
}