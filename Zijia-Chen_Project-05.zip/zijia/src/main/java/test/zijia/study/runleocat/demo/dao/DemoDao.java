package test.zijia.study.runleocat.demo.dao;

import java.util.*;

/**
 * 
 */
public interface DemoDao {

    public void findAllEmpByDeptId() ;
}