package test.zijia.study.runleocat.mallUser.service;

import test.zijia.study.runleocat.mallGood.dao.entity.MallGood;
import test.zijia.study.runleocat.mallUser.controller.viewObj.MallOrderGoodViewBean;
import test.zijia.study.runleocat.util.Result;

import java.util.List;

public interface MallUserService {
    public Result userLogin(String mallUserName, String mallUserPassword);

    List<MallOrderGoodViewBean> getUserOrderAndGoods(String mallUserName);

    Result userShopping(String mallUserName, Long mallGoodId);

    List<MallGood> findAllMallGoods();
}
