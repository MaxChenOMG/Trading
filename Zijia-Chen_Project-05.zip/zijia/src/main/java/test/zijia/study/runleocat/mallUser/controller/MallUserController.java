package test.zijia.study.runleocat.mallUser.controller;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import test.zijia.study.runleocat.mallGood.dao.entity.MallGood;
import test.zijia.study.runleocat.mallUser.controller.para.MallUserParam;
import test.zijia.study.runleocat.mallUser.controller.viewObj.MallOrderGoodViewBean;
import test.zijia.study.runleocat.mallUser.service.MallUserService;
import test.zijia.study.runleocat.util.Result;
import test.zijia.study.runleocat.util.VerifyCodeUtils;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping(value = "/malluser-manage-api/v1")
public class MallUserController {
    @Resource
    MallUserService mallUserService;

    @RequestMapping(value = "/userLogin",method = RequestMethod.PUT)
//    @PutMapping(value = "/usegLogin")
    public Result userLogin(@RequestBody @Validated MallUserParam mallUserParam){
        /**
         * 1. get input param
         *  userName
         *  userPassword
         * 2. call user service
         * 3. user service
         *      call user dao
         *          get user object from db
         *    check the object of db and input param
         *      password
         *
         *      if passs ---> login
         *      else ---> failed
         */
        System.out.println(mallUserParam.getMallUserName());
        System.out.println(mallUserParam.getMallUserPassword());
        System.out.println(mallUserParam.getMallUserAge());

        String mallUserName =  mallUserParam.getMallUserName();
        String mallUserPassword =  mallUserParam.getMallUserPassword();

         return mallUserService.userLogin(mallUserName,mallUserPassword);


//        if("".equals(mallUserParam.getMallUserName())){
//            //threw excepction
//        }else {
//            if("".equals(mallUserParam.getMallUserPassword())){
//                //threw excepction
//            }else {
//                mallUserService.userLogin();
//            }
//        }
    }

    @RequestMapping(value = "/getUserOrderAndGoods",method = RequestMethod.POST)
    public Result getUserOrderAndGoods(@RequestBody @Validated MallUserParam mallUserParam){
        return Result.success(mallUserService.getUserOrderAndGoods(mallUserParam.getMallUserName()));

    }
    @RequestMapping(value="/userShopping",method = RequestMethod.POST)
    public Result<Result> userShopping(@RequestBody @Validated MallUserParam mallUserParam){
        String mallUserName = mallUserParam.getMallUserName();
        Long mallGoodId= mallUserParam.getMallGoodId();

//        if("".equals(mallUserName)){
//            threw lk;jfkla;sjd
//        }else {
//
//        }
        return Result.success(mallUserService.userShopping(mallUserName,mallGoodId));
    }

    @RequestMapping(value = "/getMallGoodsAllByGet", method = RequestMethod.GET)
    @ResponseBody
    public Result getMallGoodsAllByGet(){
        List<MallGood> mallGoods = mallUserService.findAllMallGoods();

        return Result.success(mallGoods);
    }



    @GetMapping("/verifyImg")
    public void generateVerifyImg(HttpSession session,
                                  HttpServletResponse response)
            throws IOException {
        //生成随机验证码
        String code = VerifyCodeUtils.generateVerifyCode(4);
        //将验证码存入session，便于与用户的输入进行比对
        session.setAttribute("code",code);
        //设置响应的类型
        response.setContentType("image/png");
        //将验证码写入到图片中，并通过response响应图片
        ServletOutputStream os = response.getOutputStream();
        VerifyCodeUtils.outputImage(180,50,os,code);
    }
    @PostMapping("matchVerifyCode")
    @ResponseBody
    public Result matchVerifyCode(@RequestParam String verifyCode, HttpSession session ){
        String code = session.getAttribute("code").toString();
        System.out.println("code = " + code);
        System.out.println("verifyCode = " + verifyCode);
        if (code.equalsIgnoreCase(verifyCode)) {
            return Result.success();
        }else{
            return Result.error("200","验证码输入错误，请重新输入！");
        }
    }
}
