package test.zijia.study.runleocat.mallOrder.dao.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import test.zijia.study.runleocat.mallUser.dao.entity.MallUser;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Set;

@Entity
@Setter
@Getter
@EntityListeners(AuditingEntityListener.class)
public class MallOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "mall_order_id", nullable = false)
    private Long mallOrderId;

    private String mallOrderName;

    @CreatedDate
    private LocalDateTime createTime;
    @LastModifiedDate
    private LocalDateTime updateTime;


    @JsonIgnore
    @ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY, optional = false)
    private MallUser mallUser;


    @OneToMany(cascade = CascadeType.MERGE, mappedBy = "mallOrder")
    private Set<MallOrderGood> mallOrderGoods;

}
