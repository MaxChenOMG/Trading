package test.zijia.study.runleocat.mallOrder.dao.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import test.zijia.study.runleocat.mallOrder.dao.entity.MallOrder;

public interface MallOrderRepository extends JpaRepository<MallOrder, Long> {
}