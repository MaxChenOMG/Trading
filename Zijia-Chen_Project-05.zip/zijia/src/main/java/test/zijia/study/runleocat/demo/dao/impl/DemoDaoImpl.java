package test.zijia.study.runleocat.demo.dao.impl;

import org.springframework.stereotype.Service;
import test.zijia.study.runleocat.demo.dao.DemoDao;

/**
 * 
 */
@Service
public class DemoDaoImpl implements DemoDao {


    @Override
    public void findAllEmpByDeptId() {

    }
}