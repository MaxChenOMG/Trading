package test.zijia.study.runleocat.mallUser.dao.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import test.zijia.study.runleocat.mallUser.dao.entity.MallUser;

public interface MallUserRepository extends JpaRepository<MallUser, Long> {
    MallUser findByMallUserName(String mallUserName);

    @Query("select m from MallUser m where m.mallUserName = :mallUserName and m.mallUserPassword = :mallUserPassword")
    MallUser findUserByUserNamePass(@Param("mallUserName") String mallUserName, @Param("mallUserPassword") String mallUserPassword);

    @Query("select m from MallUser m where m.mallUserName = ?1 and m.mallUserPassword = ?2")
    MallUser findByUP(String mallUserName, String mallUserPassword);

    @Query(nativeQuery = true,value = "select * from mall_user m where m.mall_user_name = ?1 ")
    MallUser findByUPBySQL(String mallUserName);

    @Transactional
    @Modifying
    @Query("update MallUser m set m.mallUserAddress = ?1 where m.mallUserName = ?2")
    int updateUserByName(String mallUserAddress, String mallUserName);

    long deleteByMallUserName(String mallUserName);

    @Transactional
    @Modifying
    @Query("delete from MallUser m where m.mallUserName = ?1")
    int deleteUserByUserName(String mallUserName);


}