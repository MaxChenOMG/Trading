package test.zijia.study.runleocat.mallGood.dao.entity;

import lombok.Getter;
import lombok.Setter;
import test.zijia.study.runleocat.mallOrder.dao.entity.MallOrderGood;

import javax.persistence.*;
import java.util.Collection;
import java.util.Set;

@Setter
@Getter
@Entity
public class MallGood {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "mall_good_id", nullable = false)
    private Long mallGoodId;

    private String mallGoodName;
    private String mallGoodPrice;

    @OneToMany(cascade = CascadeType.MERGE, mappedBy = "mallGood")
    private Set<MallOrderGood> mallOrderGoods;

}
