package test.zijia.study.runleocat.demo.service.impl;

import org.springframework.stereotype.Service;
import test.zijia.study.runleocat.demo.dao.DemoDao;
import test.zijia.study.runleocat.demo.service.DemoService;

import javax.annotation.Resource;

/**
 * 
 */
@Service
public class DemoServiceImpl implements DemoService {

    /**
     * 
     */
    @Resource
    private DemoDao DemoDaoImpl;


    @Override
    public void getAllEmpOfDeptServ() {

    }
}