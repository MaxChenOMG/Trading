package test.zijia.study.runleocat.demo.controller;

import org.springframework.web.bind.annotation.RestController;
import test.zijia.study.runleocat.demo.service.DemoService;

import javax.annotation.Resource;

/**
 * 
 */
@RestController
public class DemoControler {

    /**
     * Default constructor
     */
    public DemoControler() {
    }

    /**
     * 
     */
    @Resource
    private DemoService DemoServiceImpl;

    /**
     * 
     */
    public void getAllEmpOfDept() {
        // TODO implement here
    }

}