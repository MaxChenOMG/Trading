package test.zijia.study.runleocat.mallUser.service.impl;

import org.springframework.stereotype.Service;
import test.zijia.study.runleocat.mallGood.dao.entity.MallGood;
import test.zijia.study.runleocat.mallGood.dao.entity.repo.MallGoodRepository;
import test.zijia.study.runleocat.mallOrder.dao.entity.MallOrder;
import test.zijia.study.runleocat.mallOrder.dao.entity.MallOrderGood;
import test.zijia.study.runleocat.mallUser.controller.viewObj.MallOrderGoodViewBean;
import test.zijia.study.runleocat.mallUser.dao.entity.MallUser;
import test.zijia.study.runleocat.mallUser.dao.repo.MallUserRepository;
import test.zijia.study.runleocat.mallUser.service.MallUserService;
import test.zijia.study.runleocat.util.Result;

import javax.annotation.Resource;
import java.time.LocalTime;
import java.util.*;

@Service
public class MallUserServiceImpl implements MallUserService {
    @Resource
    MallUserRepository mallUserRepository;

    @Resource
    MallGoodRepository mallGoodRepository;
    @Override
    public Result userLogin(String mallUserName, String mallUserPassword) {
       MallUser mallUser = mallUserRepository.findByMallUserName(mallUserName);
       if(mallUserPassword.equals(mallUser.getMallUserPassword())){
           // success obj
           return Result.success(mallUser);
       }else{
           // fail msg
           return Result.error("101","user name or password is not correct.");
       }

    }

    @Override
    public List<MallOrderGoodViewBean> getUserOrderAndGoods(String mallUserName) {
        List<MallOrderGoodViewBean> mallOrderGoodViewBeans = new ArrayList<>();
        MallUser mallUser = mallUserRepository.findByMallUserName(mallUserName);
        Set<MallOrder> mallOrders = mallUser.getMallOrders();
        Iterator moit = mallOrders.iterator();
        while (moit.hasNext()){
            MallOrder mallOrder = (MallOrder) moit.next();
            Set<MallOrderGood> mallOrderGoods = mallOrder.getMallOrderGoods();

            Iterator moog = mallOrderGoods.iterator();
            while (moog.hasNext()){
                MallOrderGood mallOrderGood = (MallOrderGood) moog.next();
                MallGood tempMallGood = mallOrderGood.getMallGood();

                MallOrderGoodViewBean mallOrderGoodViewBean = new MallOrderGoodViewBean();
                mallOrderGoodViewBean.setMallOrderName(mallOrder.getMallOrderName());
                mallOrderGoodViewBean.setMallGoodPrice(tempMallGood.getMallGoodPrice());
                mallOrderGoodViewBean.setMallGoodName(tempMallGood.getMallGoodName());

                mallOrderGoodViewBeans.add(mallOrderGoodViewBean);
            }
        }
        return mallOrderGoodViewBeans;
    }

    @Override
    public Result userShopping(String mallUserName, Long mallGoodId) {
        MallUser mallUser = mallUserRepository.findByMallUserName(mallUserName);
        Set<MallOrder> mallOrders = new HashSet<>();

        MallGood mallGood = mallGoodRepository.findById(mallGoodId).get();

        MallOrder mallOrder = new MallOrder();
        mallOrder.setMallOrderName("O01"+ LocalTime.now());
        mallOrder.setMallUser(mallUser);

        MallOrderGood mallOrderGood = new MallOrderGood();
        mallOrderGood.setMallGood(mallGood);
        mallOrderGood.setMallOrder(mallOrder);
        mallOrderGood.setMallOrderName(mallOrder.getMallOrderName());

        Set<MallOrderGood> mallOrderGoods = new HashSet<>();
        mallOrderGoods.add(mallOrderGood);
        mallGood.setMallOrderGoods(mallOrderGoods);
        mallOrder.setMallOrderGoods(mallOrderGoods);


        mallOrders.add(mallOrder);
        mallUser.setMallOrders(mallOrders);

        MallUser mallUserRs = mallUserRepository.save(mallUser);

        return Result.success(mallUserRs);
    }

    @Override
    public List<MallGood> findAllMallGoods() {
        return mallGoodRepository.findAll();
    }
}
