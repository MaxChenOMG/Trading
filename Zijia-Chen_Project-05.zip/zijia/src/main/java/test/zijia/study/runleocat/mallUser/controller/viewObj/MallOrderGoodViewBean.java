package test.zijia.study.runleocat.mallUser.controller.viewObj;

import lombok.Data;

@Data
public class MallOrderGoodViewBean {
    private String mallGoodName;
    private String mallGoodPrice;
    private String mallOrderName;
}
