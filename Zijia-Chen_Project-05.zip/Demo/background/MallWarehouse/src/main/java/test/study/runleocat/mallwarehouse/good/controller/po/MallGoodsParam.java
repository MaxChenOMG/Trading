package test.study.runleocat.mallwarehouse.good.controller.po;

import lombok.Data;

import java.util.List;

@Data
public class MallGoodsParam {
    private List<Long> mallGoodsList;
}
