package test.study.runleocat.mallwarehouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallWarehouseApplication {

    public static void main(String[] args) {
        SpringApplication.run(MallWarehouseApplication.class, args);
    }

}
