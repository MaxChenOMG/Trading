package test.study.runleocat.malluser.malluser.controller.vo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MallGood {
    private Long mallGoodId;
    private String mallGoodName;
    private String mallGoodPrice;
    private String mallGoodType;
    private String mallGoodArea;
    private String mallGoodStatus;
}
